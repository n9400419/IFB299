-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team_49
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `search_museum`
--

LOCK TABLES `search_museum` WRITE;
/*!40000 ALTER TABLE `search_museum` DISABLE KEYS */;
INSERT INTO `search_museum` VALUES (1,'Museum of Brisbane','Level 3, City Hall | King George Square, Brisbane, Queensland 4001, Australia','aa@.com','3999 0800','http://www.museumofbrisbane.com.au ','The Museum of Brisbane is a museum that explores contemporary and historic Brisbane, Australia, and its people through a program of art and social history exhibitions, workshops, talks, tours and children\'s activities.'),(2,'Queensland Museum','Grey St & Melbourne St, South Brisbane QLD 4101, Australia','aaa@.com','3840 7555','http://www.qm.qld.gov.au ','The Queensland Museum is the state museum of Queensland, Australia. The museum currently operates five separate campuses; at South Brisbane, Ipswich, Toowoomba, Townsville and Wooloongabba. The museum is funded by the State Government of Queensland.'),(3,'Queensland Maritime Museum','Southbank | (near the Goodwill Bridge), Brisbane, Queensland 4101, Australia','aaa@.com','3844 5361','https://maritimemuseum.com.au ','The Queensland Maritime Museum is located on the southern bank of the Brisbane River just south of the South Bank Parklands and Queensland Cultural Centre precinct of Brisbane, and close to the Goodwill Bridge.'),(4,'Sir Thomas Brisbane Planetarium','Mount Cootha Rd, Toowong QLD 4066, Australia','aaa@.com','3403 2578','https://www.brisbane.qld.gov.au/facilities-recreation/arts-culture/planetarium/visiting-planetarium ','The Sir Thomas Brisbane Planetarium was established in 1978 by Brisbane City Council. '),(5,'Old Government House',' 2 George Street Brisbane QLD 4001Australia','ogh.enquiries@qut.edu.au ','3138 8005','http://www.ogh.qut.edu.au/visiting/ ','Old Government House was the hub of colonial life in the early days of Brisbane. ');
/*!40000 ALTER TABLE `search_museum` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-31 15:55:33
