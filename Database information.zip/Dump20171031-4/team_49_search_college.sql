-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team_49
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `search_college`
--

LOCK TABLES `search_college` WRITE;
/*!40000 ALTER TABLE `search_college` DISABLE KEYS */;
INSERT INTO `search_college` VALUES (1,'Queensland University of Technology (QUT)','2 George St, Brisbane City QLD 4000	','askqut@qut.edu.au','Business, Econimics and Law; Engineering, Architecture & Information Technology; Health and Behavioural Sciences; Humanities and Social Sciences; Medicine; Science'),(2,'University of Queensland (UQ)','St Lucia QLD 4072','admissions@uq.edu.au','QUT Business School; Create Industries; Education; Health; Law; Science and Engineering; '),(3,'Australian Catholic University (ACU)','1100 Nudgee Rd, Banyo QLD 4014','askacu@acu.edu.au','Faculty of Education and Arts; Health Sciences; Law and Business; Theology and Philosophy '),(4,'CQUniversity','160 Ann St, Brisbane City QLD 4000','contactus@cq.edu.au','Business, Accounting and Law; Creative Arts; Education and Humanities; Engineering; Health; Information Technology; Pyschology; Science and Environment; Transport'),(5,'Griffith University','226 Grey St, South Bank QLD 4101','international@griffith.edu.au','Accounting, Finance and Economics, Employment Relations and Human Resources, Government and International Relations; International Business and Asian Studies; Marketing; Tourism, Sport and Hotel Management');
/*!40000 ALTER TABLE `search_college` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-31 15:55:33
