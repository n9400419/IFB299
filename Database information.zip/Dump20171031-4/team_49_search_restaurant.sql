-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team_49
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `search_restaurant`
--

LOCK TABLES `search_restaurant` WRITE;
/*!40000 ALTER TABLE `search_restaurant` DISABLE KEYS */;
INSERT INTO `search_restaurant` VALUES (1,'Tartufo','1000 Ann St | Fortitude Valley, Emporium, Brisbane, Queensland, Australia','info@tartufo.com','38521500','http://tartufo.com.au/','Refined Neapolitan-inspired classics with seasonal produce in a smart red and black dining room.'),(2,'Sono Japanese Restaurant Portside Wharf','39 Hercules St, Hamilton | Level 1, Building 7, Portside Wharf, Brisbane','info@sono.com','3268 6655','https://www.sonorestaurant.com.au/','Modern Japanese food, a teppanyaki bar and a sake tasting menu in a refined riverfront space.'),(3,'Blackbird Bar and Grill','123 Eagle St, Brisbane, Queensland 4000, Australia','info@blackbird.com','3229 1200','http://tartufo.com.au/','BRISBANE’S FAVOURITE RIVERSIDE RESTAURANT & BAR'),(4,'Bacchus','Rydges South Bank, Podium Level | 9 Glenelg Street, Brisbane','info@bacchus.com','33640837','http://www.bacchussouthbank.com.au/','Upscale Modern Australian dishes, plus clever cocktails, in a glamorous poolside restaurant and bar.'),(5,'Longtime','610 Ann St, Brisbane, Queensland 4006, Australia','info@longtime.com','3160 3123','https://www.longtime.com.au/','Welcome to LONgTIME, our take on casual, street-inspired South-East Asian food, with a focus on info');
/*!40000 ALTER TABLE `search_restaurant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-31 15:55:33
