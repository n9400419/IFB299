-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team_49
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `search_mall`
--

LOCK TABLES `search_mall` WRITE;
/*!40000 ALTER TABLE `search_mall` DISABLE KEYS */;
INSERT INTO `search_mall` VALUES (1,'Queen Street Mall',' Queen Street mall, Queen St, Brisbane City QLD 4000, Australia','qsm@brisbanemarketing.com.au ','3006 6290','http://www.visitbrisbane.com.au/the-city/things-to-do/shopping/queen-street-mall?sc_lang=en-au','The Queen Street Mall is a vibrant shopping and lifestyle precinct that lies at the heart of Brisbane.'),(2,'James Street Precinct ','James St, Fortitude Valley, QLD 4006 Australia','info@jamesst.com.au','3850 0111 ','http://www.jamesst.com.au ','James Street is a two minute stroll from the heart of Fortitude Valley and is without a doubt the place to be seen. '),(3,'DFO','18th Avenue, Skygate, Brisbane Airport QLD 4008','DFOBrisbane.Reception@vicinity.com.au','3305 9250','https://www.dfo.com.au/brisbane/ ','Next to Brisbane Airport, this retail super hub offers shoppers more than 120 leading Australian and international brands at up to 70 per cent lower prices - all under one roof.'),(4,'Westfield Chermside Shopping Centre','Cnr Gympie & Hamilton Rds Chermside/Brisbane QLD 4032 ','info@westfield.com','3117 5300','https://www.westfield.com.au ','One of many Westfield Centres in Brisbane.'),(5,'Westfield Carindale Shopping Centre','1151 Creek Road Carindale/Brisbane QLD 4152','info@westfield.com','3120 5400','https://www.westfield.com.au/carindale','One of many Westfield Centres in Brisbane.');
/*!40000 ALTER TABLE `search_mall` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-31 15:55:33
