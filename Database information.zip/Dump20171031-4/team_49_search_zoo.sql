-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team_49
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `search_zoo`
--

LOCK TABLES `search_zoo` WRITE;
/*!40000 ALTER TABLE `search_zoo` DISABLE KEYS */;
INSERT INTO `search_zoo` VALUES (1,'Lone Pine Koala Sanctuary','708 Jesmond Rd, Fig Tree Pocket','service@koala.net ','3378 1366','http://koala.net/en-au/','Lone Pine Koala Sanctuary is an 18-hectare Koala Sanctuary in the Brisbane suburb of Fig Tree Pocket in Queensland, Australia. Founded in 1927, it is the world\'s oldest and largest koala sanctuary.'),(2,'Daisy Hill Koala Sanctuary ','Regional Park, 253 Daisy Hill Rd, Daisy Hill ','koala.centre@ehp.qld.gov.au ','3299 1032','https://www.ehp.qld.gov.au/wildlife/daisyhill-centre/','Built by the Queensland Government as a dedicated koala education facility, the Daisy Hill Koala Centre was opened to the public in 1995. Extensively refurbished in 2009, it features a large outdoor koala enclosure and many interactive displays.'),(3,'Brisbane Forest Park','60 Mt Nebo Road, THE GAP, QLD 4061','brisbaneforestpark@epa.qld.gov.au','3300 4855','https://www.npsr.qld.gov.au/parks/daguilar/','Brisbane Forest Park, is located on parts of the D\'Aguilar Range. The large nature reserve lies on the western boundary of City of Brisbane into the Moreton Bay Region, Queensland, Australia,'),(4,'Alma Park Zoo','PO Box 35, Kallangur, QLD Australia 4503','info@almapark.com','3204 6566','http://www.almaparkzoo.com.au/','Alma Park Zoo was a 40-acre zoo located north of Brisbane, Australia, in Dakabin on Alma Road. The small 20-acre park was filled with Australian and exotic species.'),(5,'Australia Zoo','1638 Steve Irwin Way, Beerwah QLD 4519','info@australiazoo.com','5436 2000 ','www.australiazoo.com.au','Australia Zoo is a 100-acre zoo located in the Australian state of Queensland on the Sunshine Coast near Beerwah/Glass House Mountains.');
/*!40000 ALTER TABLE `search_zoo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-31 15:55:33
