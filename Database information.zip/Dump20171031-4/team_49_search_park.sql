-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team_49
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `search_park`
--

LOCK TABLES `search_park` WRITE;
/*!40000 ALTER TABLE `search_park` DISABLE KEYS */;
INSERT INTO `search_park` VALUES (1,'Botanic Gardens Mt Coot-tha','Mt Coot-tha Road, Toowong','aaa@.com','3403 2532','https://www.brisbanelookout.com/mt-coot-tha-botanic-gardens','The Brisbane Botanic Gardens are located 7 kilometres from the Brisbane CBD in Toowong, Queensland, Australia, at the foot of Brisbane\'s tallest mountain, Mount Coot-tha.'),(2,'Roma Street Parkland','1 Parkland Blvd, Brisbane','aaa@.com','3463 1114','http://www.visitbrisbane.com.au/roma-street-parkland-and-spring-hill?sc_lang=en-au ','Roma Street Parkland covers 16 hectares in the centre of Brisbane, Australia. The Roma Street Parkland is adjacent to Brisbane Transit Centre and the Roma Street Station.'),(3,'Southbank Parkland','Little Stanley Street, South Brisbane','aaa@.com','3153 6366','http://www.visitbrisbane.com.au/south-bank?sc_lang=en-au','The South Bank Parklands is one of Australia’s most pristine outdoor spaces.'),(4,'City Botanic Gardens ','Alice St, Brisbane City','aaa@.com','3403 8888','https://www.brisbane.qld.gov.au/facilities-recreation/parks-venues/parks/city-botanic-gardens','The City Botanic Gardens is a heritage-listed botanic garden on Alice Street, Brisbane City, City of Brisbane, Queensland, Australia. It was also known as Queen\'s Park.'),(5,'New Farm Park','1038 Brunswick Street, New Farm, Queensland 4005','aaa@.com','3403 8888','http://www.newfarmpark.com.au/','New Farm Park is a public park in the suburb of New Farm in Brisbane, Queensland, Australia. The park covers 15 hectares and is at the southeastern end of the New Farm peninsula on a bend in the Brisbane River.');
/*!40000 ALTER TABLE `search_park` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-31 15:55:33
